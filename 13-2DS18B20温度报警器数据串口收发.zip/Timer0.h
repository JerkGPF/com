#ifndef __Timer0_H__
#define __Timer0_H__

void Timer0Init(void);		//1毫秒@12.000MHz


#endif
