#ifndef __UART_H__
#define __UART_H__

void UART_Init();//4800bps@11.0592MHz
void UART_SendByte(unsigned char Byte);
void UART_ShowString(char *String);
#endif
