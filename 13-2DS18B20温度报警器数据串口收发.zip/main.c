#include <REGX52.H>
#include "LCD1602.h"
#include "DS18B20.h"
#include "Delay.h"
#include "AT24C02.h"
#include "Key.h"
#include "Timer0.h"
#include "Buzzer.h"
#include "UART.h"
#include <stdlib.h>
#include <stdio.h>
float T,TShow;
char TLow,THigh;
unsigned char KeyNum;
char str[10] = "";

void main()
{
	DS18B20_ConvertT();//上电先转换一次温度，防止第一次读数据错误
	Delay(1000);			//等待转换完成
	
	THigh = AT24C02_ReadByte(0);//读取温度阈值数据
	TLow = AT24C02_ReadByte(1);
	if(THigh>125||TLow<-55||THigh<=TLow)//如果阈值非法，则设为默认值
	{
		THigh = 20;
		TLow = 15;
	}
	UART_Init();
	LCD_Init();
	LCD_ShowString(1,1,"T:");
	LCD_ShowString(2,1,"TH:");
	LCD_ShowString(2,9,"TL:");
	LCD_ShowSignedNum(2,4,THigh,3);
	LCD_ShowSignedNum(2,12,TLow,3);
	Timer0Init();
	while(1)
	{
		KeyNum = Key();
		/*温度读取及显示*/
		DS18B20_ConvertT();			//转换温度
		T = DS18B20_ReadT();		//读取温度
		if(T<0)									//如果温度小于0
		{
			LCD_ShowChar(1,3,'-'); //显示负号
			TShow = -T;            //将温度变为正数
		}
		else    									//如果温度大于等于0
		{
			LCD_ShowChar(1,3,'+');   //显示正号
			TShow = T;
		}
		LCD_ShowNum(1,4,TShow,3);   //显示温度整数部分
		LCD_ShowChar(1,7,'.');			//显示小数点
		LCD_ShowNum(1,8,(unsigned long)(TShow*1000)%1000,3);//显示温度小数部分
			
		UART_ShowString("0xff,");	
		sprintf(str,"%0.3f",TShow);
		UART_ShowString(str);
		UART_ShowString(",0xfd");

		LCD_ShowChar(1,11,0xDF);//显示°C
		//LCD_ShowChar(1,12,'C');//显示°C
		/*阈值判断及显示*/
		if(KeyNum)
		{
			if(KeyNum==1) 	//K1按键，THigh自增
			{
				THigh++;
				if(THigh>125) THigh = 125;
			} 
			if(KeyNum==2) 	//K2按键，THigh自减
			{
				THigh--;
				if(THigh<=TLow) THigh++;
			}
			if(KeyNum==3) 	//K3按键，TLow自增
			{
				TLow++;
				if(TLow>=THigh) TLow--;
			}
			if(KeyNum==4) 	//K4按键，TLow自减
			{
				TLow--;
				if(TLow<-55) TLow = -55;
			}
			LCD_ShowSignedNum(2,4,THigh,3);	//显示阈值数据
			LCD_ShowSignedNum(2,12,TLow,3);
			//存储
			AT24C02_WriteByte(0,THigh);		//写入到At24C02中保存
			Delay(5);
			AT24C02_WriteByte(1,TLow);
			Delay(5);
		}
		if(T>THigh)							//越界判断
		{
			LCD_ShowString(1,13,"OV:H");//显示越界提示
			//Buzzer_Time(1000);//蜂鸣器发出警报

			//Delay(100);
		
		}
		else if(T<TLow)
		{
			LCD_ShowString(1,13,"OV:L");//显示越界提示
			//Buzzer_Time(1000);//蜂鸣器发出警报
			//Delay(100);
		
		}
		else
		{
			LCD_ShowString(1,13,"    ");
	  }

	}
}
